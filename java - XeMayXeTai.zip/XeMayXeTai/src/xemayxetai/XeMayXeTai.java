package xemayxetai;
public class XeMayXeTai {
    public static void main(String[] args) {
        XeMay x1=new XeMay();
        x1.xeChay(3, 10, 100);//xang, hang, duong
        System.out.print("Xang con:"+x1.xangCon());
    }
    
}
